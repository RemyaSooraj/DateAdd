﻿
/**
* FileName : DateCalculation.js
* Description  : This has the logic to compute date based
* on the input date and number of days
* 
*/

/**
 * Name : IsValidNumber
 * Purpose  : To allow only Numeric values in the Days field
 */
function IsValidNumber(event) {
    event = (event) ? event : window.event;
    var charCode = (event.which) ? event.which : event.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
        return false;
    }
    return true;
}

/**
 * Name : DisplayCalculatedDate
 * Purpose  : To display the calculated date to a text field
 * */
function DisplayCalculatedDate() {

    var date = new Date($('#DateText').val());
    if ($("#Days").val() != "")
    {
            var daysToAdd = parseInt($("#Days").val());
            currentDay = date.getDate();
            currentMonth = date.getMonth() + 1;
            currentYear = date.getFullYear();

            var newDate = AddDates(currentDay, daysToAdd, currentMonth, currentYear);

            $("#Message").text(newDate);
    }
    else
    {
        $("#Message").text("Provide no.of days");
    }
}

/**
 * Name : AddDates
 * Purpose : Logic for date calculation
 * @param CurrentDay - Chosen day of the date
 * @param Count - No.of days to be added
 * @param Month - Chosen Month of the date
 * @param Year - Chosen Year of the date
 */
function AddDates(CurrentDay, Count, Month, Year) {
    var totalDays = CurrentDay + Count;

    /*Array for holding months which have 30 days*/
    var monthData30 = [4, 6, 9, 11];

    //Array for holding month values which have 31 days
    var monthData31 = [1, 3, 5, 7, 8, 10, 12];

    var isAvailable = false;
    var computedDate = "";

    /*Logic for minor calculations
     The computed  date comes in the same month and year as the chosen one*/
    if (totalDays <= 28) {
        computedDate = totalDays + "/" + Month + "/" + Year;
    }
    /*The computed date  goes to different month(s) or even year(s)
     */
    else {
        var excessDays = 0;

        do {
            /*For February logic should take care of Leap Year
             */
            if (Month == 2) {
                /*Leap year logic
                 * An year should be divisible for 4 and not divisible by 100 and divisible by 400 in some cases */
                var isLeapYear = ((Year % 4 == 0) && (Year % 100 != 0)) || (Year % 400 == 0);
                if (isLeapYear) {
                    excessDays = parseInt(totalDays) - 29;

                }
                /* To get the correct number of days in the case of lengthy calculations involving
                 * multiple months spanned across year(s)*/
                else {
                    excessDays = parseInt(totalDays) - 28;
                }
            }
            /*See if the Month falls amonsgst those which has 30 days
             */
            else if (jQuery.inArray(Month, monthData30) != -1) {
                excessDays = parseInt(totalDays) - 30;
            }
            /*See if the Month falls amonsgst those which has 31 days
            */
            else if (jQuery.inArray(Month, monthData31) != -1) {
                excessDays = parseInt(totalDays) - 31;

            }
            if (Month != 12) {
                Month = Month + 1;
            }
            else {
                Month = 1;
                Year = Year + 1;
            }

            totalDays = excessDays;

            computedDate = excessDays + "/" + Month + "/" + Year;
        }
        while (excessDays > 28)
    }

    return computedDate;
}
